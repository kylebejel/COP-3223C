/*
Name: Kyle Bejel
Date: 2/4/2019
Project: WeatherFunction
Instructor: Leinecker
*/

#include <stdlib.h>
#include <stdio.h>

//create function
void talkAboutTheWeather() {
  //print multiple statements about the weather
  printf("Today is pretty cool, around 68 degrees.\n");
  printf("It is pretty sunny outside and most likely won't rain.\n");
  printf("It is not very humid outside.\n");
  printf("We are about to reach Spring.\n");

}


int main() {
  //call function
  talkAboutTheWeather();

  return 0;
}
