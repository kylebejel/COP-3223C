/*
Author: Kyle Bejel
Project Name: WeatherTalk
Date: 1/13/2019
Instructor: Leinecker
*/
#include <stdio.h>
#include <stdlib.h>

int main(){
  /* print statements about temperature */
  printf("It isn't too hot outside today, probably around 72 degrees. It is quite nice.\n");
  /* print statements about humidity */
  printf("It actually isn't very humid right now, I guess it hasn't rained in a while\n");
  /* print statements about chance of rain */
  printf("It is not raining right now and I don't expect it too rain soon\n");

  return 0;
}
