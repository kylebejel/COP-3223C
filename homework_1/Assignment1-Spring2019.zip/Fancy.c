/*
Author: Kyle Bejel
Project Name: Fancy
Date: 1/13/2019
Instructor: Leinecker
*/
#include <stdio.h>
#include <stdlib.h>

int main(){
/* print statements that make a cool face */

  printf("*******************************************\n");
  printf("*                                         *\n");
  printf("*               *******                   *\n");
  printf("*              *       *                  *\n");
  printf("*             *  *   *  *                 *\n");
  printf("*             *    ^    *                 *\n");
  printf("*              * \\--/  *                  *\n");
  printf("*               *******                   *\n");
  printf("*                                         *\n");
  printf("*******************************************\n");

  return 0;
}
