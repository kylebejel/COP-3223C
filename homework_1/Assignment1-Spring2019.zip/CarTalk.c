/*
Author: Kyle Bejel
Project Name: CarTalk
Date: 1/13/2019
Instructor: Leinecker
*/
#include <stdio.h>
#include <stdlib.h>

int main(){
  /* print statements about not having a car :( */
  printf("I, sadly, do not have a car. But my friend's car is pretty nice.\n");
  /* print statements about car model */
  printf("He has a white Dodge Avenger, and it's a fun car to be in.\n");
  /* print statements about modifications my friend has made to his car */
  printf("He's added LEDs, a stero system, some seat covers, and a bunch of other cool stuff.\n");
  /* print statements about the unfortunate walk to the garage */
  printf("Unfortunately, we have to walk to Libra Garage in order to use it.\n");


  return 0;
}
