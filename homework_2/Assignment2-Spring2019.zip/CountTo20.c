/*
Author: Kyle Bejel
Project Name: CountTo20
Date: 1/20/2019
Instructor: Leinecker
*/
#include <stdio.h>
#include <stdlib.h>

int main() {

  /* print empty line (stylistic choice) */
  printf("\n");
  /* create for loop that increments from 0-20 */
  for(int i = 0; i < 21; i++){
    /* print counter value throughout the for loop */
    printf("The counter value is now %d\n", i);
  }

  return 0;

}
